import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class tetrox extends PApplet {

//
//                            TETROX
//

SoundFile music1;
SoundFile music2;
SoundFile cadutaBloccoSound;
SoundFile eliminaRigaSound;
SoundFile gameOverSound;

PImage sprite;

Gui interfaccia;
Grid griglia;

int timeGame = 0; //tempo di gioco effettivo
int timeoffset = 0; //offset di tempo accumulato al menu princ e durante le pause
int h = 20; //righe
int w = 10; //colonne


ArrayList<Blocco> blocks = new ArrayList<Blocco>();
boolean bloccoInDiscesa = false;  //è true quando un blocco sta scendendo e non ne serve uno nuuovo
int blockOffset = 700; //offset di default per la caduta dei blocchi
int aum = 700;  //aumento di block offset, più è piccolo e più è veloce a scendere
int aumDefault = 700;

int punti = 0; //tutte queste var si spiegano da sole credo
int lvl = 0;
int nextLvl = 0;
int righeEliminate = 0;
boolean pausa = false;
boolean avviato = false; //ho premuto z o no?
boolean gameOver = false;

int musicTrack = 1; //traccia musicale selez
boolean musicLoaded = false;

int nextBlock = (int)random(8);  //indica la tipologia del blocco successivo (in anteprima), viene randomizzato all'inizio per stabilire il primo blocco
BlockManager manager = new BlockManager();  //gestore nuovi blocchi

public void setup() {
   //stampo schermata di loading mentre il programma carica le sue musiche
  background(9, 9, 9);
  textSize(30);
  textAlign(CENTER);
  fill(0xffd93444);
  text("LOADING", 300, 300);

  interfaccia = new Gui(); //inizializzo la gui
  griglia = new Grid(h, w); //inizializzo la griglia di gioco

  sprite = loadImage("block.png"); //carico le sprite dei blocchi

  cadutaBloccoSound = new SoundFile(this, "cadutaBlocco.wav"); //carico i vari effetti sonori + musica
  eliminaRigaSound = new SoundFile(this, "eliminaRiga.wav");
  gameOverSound = new SoundFile(this, "gameOver.wav");
  music1 = new SoundFile(this, "music1.mp3");
  music2 = new SoundFile(this, "music2.mp3");
  cadutaBloccoSound.amp(0.4f); //fixo l'effetto strano
}

public void draw() {
  if (avviato && musicLoaded) 
    drawGame(); //gioco se ho avviato e caricato la musica
  else //altrimenti stampo il menu principale
    interfaccia.stampoMenu();

  if (gameOver) 
    interfaccia.stampoGameOver(); //se sono in gameover richiamo stampoGameOver
}

public void drawGame() {
  fill(9, 9, 9); //colore bg e tab sx in alto
  background(35, 35, 35);
  rect(200, 0, 400, height);
  noFill();

  if (millis()-timeoffset > blockOffset) {  //"delay" fittizio, esegue la logica della caduta solamente ogni aum millisecondi 
    if (!bloccoInDiscesa) {  //se non scende nulla creo blocco nuovo
      //crea blocco
      manager.loadBlocks(nextBlock, blocks, griglia);  //spawno nuovo blocco multiplo

      nextBlock = (int)random(8); //randomizza il blocco successivo
      manager.loadBlocksAnteprima(nextBlock, interfaccia.leftBlocks);  //genero l'anteprima dei blocchi riempiendo l'array di blocchi di sinistra

      bloccoInDiscesa = true;
    } else {
      bloccoInDiscesa = update(griglia, blocks, h);  //eseguo la discesa dei blocchi con "update", ritorna se il blocco sta scendendo o se è alla fine
      if (!bloccoInDiscesa)  //se ha finito di scendere ripristino la velocità normale, serve in caso di hard drop perché aum diventa 0
        aum = aumDefault;
    }

    blockOffset+=aum;
  }

  griglia.updateGriglia(blocks); //update della griglia  

  if (!bloccoInDiscesa) //controllo eliminazione riga
    griglia.controlloEliminazione(blocks);

  translate(200, 0); //mi sposto nella zona di gioco
  for ( Blocco i : blocks) //stampo i blocchi
    i.show();

  interfaccia.mostra(); //stampo gui

  timeGame = millis(); //calcoli per il tempo
}

public void keyPressed() {
  int mov = 0;  //conterrà il codice per l'eventuale movimento orizzontale

  if (avviato && (!pausa && bloccoInDiscesa)) {
    //per muoversi orizzontalmente non deve esserci pausa e il blocco deve stare scendendo
    //altrimenti nell'ultima riga può continuare a muoversi e continua a scendere mentre si è in pausa
    if (key == CODED) {
      if (keyCode == LEFT) {
        mov = -1;
      } else if (keyCode == RIGHT) {
        mov = 1;
      } else if (keyCode == DOWN && aum == aumDefault) {  //aumento velocità solo se non è già aumentata
        aum/=2;
      }

      movimentoOrizzontale(griglia, blocks, mov, w);  //se scende lo faccio muovere
    }
  }

  if ((key == 'p'|| key== 'P') && gameOver==false) { //tasto pausa, controllo che non sia gameover
    int timetemp = millis();
    if (!pausa && avviato) { //metto in pausa
      noLoop();
      pausa=true;
      timeGame = millis(); //salvo millis al momento dell'inizio pausa
      interfaccia.stampoPausa();
    } else if (pausa && avviato) {  //esco dalla pausa
      loop(); 
      pausa=false;
      timeoffset += timetemp - timeGame; //ricalcolo tempo con millis e offset calcolato prima
    }
  }

  //inizio
  if ((key == 'z' || key == 'Z')) { //tasto d'avvio 
    avviato = true;
  }

  //hard drop
  if ((key == 'c' || key == 'C') && pausa==false) {  //se premo h azzero il gap tra un ciclo di update e l'altro (scende ogni 0 millisecondi)
    aum = 0;
  }

  //scelgo traccia musica
  if ((key == 'a' || key == 'A') && !avviato) {
    if ( musicTrack == 1) 
      musicTrack = 2;
    else 
      musicTrack = 1;
  }
}


public void keyReleased() {
  if (avviato && !pausa && bloccoInDiscesa) {
    if (key == CODED) {
      //quando rilascio il tasto torna a normale velocità
      if (keyCode == DOWN && aum != aumDefault) {
        aum = aumDefault;
      }
    }
  }

  if ((key == 'x' || key == 'X')&& pausa==false) { //tasto di rotazione
    if (avviato) 
      manager.rotate(blocks);
  }
}
class Blocco {
  PVector pos; //salva come coord nella griglia
  int size = (width-200)/w;
  boolean del = false;  //diventa true quando il blocco va eliminato dalla lista (la sua riga è stata eliminata)
  boolean staScendendo = true;  //è true quando in discesa, viene messo a false quando raggiunge la fine
  int type; //indica il tipo di blocco multiplo a cui appartiene

  Blocco(int t, int x, int y) {
    pos = new PVector(x, y);
    type = t;
  }

  public void show() {
    switch(type) {
    case 0: 
      tint(97, 162, 255); 
      break; //azzurro
    case 1: 
      tint(227, 81, 0); 
      break; //arancio
    case 2: 
      tint(235, 211, 32); 
      break; //giallo
    case 3: 
      tint(97, 16, 162); 
      break; //viola
    case 4: 
      tint(81, 162, 0); 
      break; //verde
    case 5: 
      tint(158, 16, 48); 
      break; //rosso
    case 6: 
      tint(65, 65, 255); 
      break; //blu
    case 7: 
      tint(255, 64, 246);
      break; //lillà
    default: 
      tint(255); 
      break; //bianco
    }

    image(sprite, (pos.x)*size, (pos.y)*size);
    noTint();
  }
}

//ritorna true se il blocco è in discesa, false se si ferma
public boolean update(Grid griglia, ArrayList<Blocco> blocchi, int h) {  //scende, movimento verticale

  //genero un array con gli indici dei blocchi in discesa
  ArrayList<Integer> blocchiInDiscesa = new ArrayList<Integer>();
  for (int i = blocchi.size()-1; i >= 0; i--) {  //scorro tutti i blocchi e genero l'array
    if (blocchi.get(i).staScendendo) {
      blocchiInDiscesa.add(i);
    } else {
      break;
    }
  }

  //controllo che tutti si possano muovere, in caso contrario non muovo nulla
  boolean siPossonoMuovere = true;

  for (int i = 0; i < blocchiInDiscesa.size(); i++) {
    if (blocchi.get(blocchiInDiscesa.get(i)).pos.y < h - 1) {  //controllo che non sia già sul fondo
      //controllo blocco della griglia sotto che non sia già occupato o che sia un blocco che sta scendendo quindi appartiene al proprio blocco multiplo
      if (!(griglia.grid[(int)blocchi.get(blocchiInDiscesa.get(i)).pos.y + 1][(int)blocchi.get(blocchiInDiscesa.get(i)).pos.x] == -1 || blocchi.get(griglia.grid[(int)blocchi.get(blocchiInDiscesa.get(i)).pos.y + 1][(int)blocchi.get(blocchiInDiscesa.get(i)).pos.x]).staScendendo)) {
        siPossonoMuovere = false;
        break;
      }
    } else {
      siPossonoMuovere = false;
    }
  }

  //se si possono muovere li muovo
  if (siPossonoMuovere) {
    for (int i = 0; i < blocchiInDiscesa.size(); i++) {
      blocchi.get(blocchiInDiscesa.get(i)).pos.y ++;
    }
  }

  //se è arrivato in fondo (o il posto sotto è occupato) blocco subito la discesa
  //se non lo si facesse passerebbe un altro clock prima che si bloccasse
  for (int i = 0; i < blocchiInDiscesa.size(); i++) {
    if (!(blocchi.get(blocchiInDiscesa.get(i)).pos.y < h - 1 && (griglia.grid[(int)blocchi.get(blocchiInDiscesa.get(i)).pos.y + 1][(int)blocchi.get(blocchiInDiscesa.get(i)).pos.x] == -1 || blocchi.get(griglia.grid[(int)blocchi.get(blocchiInDiscesa.get(i)).pos.y + 1][(int)blocchi.get(blocchiInDiscesa.get(i)).pos.x]).staScendendo))) {
      if (aum == 0)
        cadutaBloccoSound.play();  //se è in hard-drop fa il suono
        
      return false;  //se ha terminato la discesa rinasce
    }
  }

  return true;  
}

//muove orizzontalmente tutti i blocchi che stanno scendendo
public static void movimentoOrizzontale(Grid griglia, ArrayList<Blocco> blocchi, int mov, int w) {  //-1 a sx 1 a dx
  //genero un array con gli indici dei blocchi in discesa
  ArrayList<Integer> blocchiInDiscesa = new ArrayList<Integer>();
  for (int i = blocchi.size()-1; i >= 0; i--) {  //scorro tutti i blocchi e genero l'array
    if (blocchi.get(i).staScendendo) {
      blocchiInDiscesa.add(i);
    } else {
      break;
    }
  }

  //controllo che tutti si possano muovere, in caso contrario non muovo nulla
  boolean siPossonoMuovere = true;

  for (int i = 0; i < blocchiInDiscesa.size(); i++) {

    //controllo prima che la x sia favorevole rispetto ai bordi, poi che il blocco in parte sia vuoto oppure che il blocco in parte stia scendendo (appartiene alla stessa forma)
    if (!(blocchi.get(blocchiInDiscesa.get(i)).pos.x + mov >= 0 && blocchi.get(blocchiInDiscesa.get(i)).pos.x + mov < w  && (griglia.grid[(int)blocchi.get(blocchiInDiscesa.get(i)).pos.y][(int)blocchi.get(blocchiInDiscesa.get(i)).pos.x + mov] == -1 || blocchi.get(griglia.grid[(int)blocchi.get(blocchiInDiscesa.get(i)).pos.y][(int)blocchi.get(blocchiInDiscesa.get(i)).pos.x + mov]).staScendendo))) {
      siPossonoMuovere = false;
    }
  }

  //se tutti si possono muovere si muovono
  if (siPossonoMuovere) {
    //scorro tutti i blocchi in discesa e li faccio muovere
    for (int i = 0; i < blocchiInDiscesa.size(); i++) {
      blocchi.get(blocchiInDiscesa.get(i)).pos.x += mov;
    }
  }
}
interface BlockType {
  int
    Straight = 0, 
    L = 1, 
    Square = 2, 
    Plus = 3, 
    Lightning = 4, 
    Short = 5, 
    Long = 6,
    NegativeLightning = 7;
}

interface FlipType {
  int
    horizontalStraight = 6, 
    left_right_L = 7, 
    up_down_L = 8, 
    left_right_Plus = 9, 
    up_down_Plus = 10, 
    left_right_Lightning = 11, 
    up_down_Lightning = 12;
}

interface RotationType {
  int
    normal = 0, 
    down_right = 1, 
    down_left = 2, 
    up_left = 3, 
    up_right = 4;
}

class BlockManager {

  int rotation_type = 0;
  boolean first = true;

  //SUMMARY
  //Si occupa di aggiungere i blocchi nella lista, per disegnare le forme.
  public void loadBlocks(int type, ArrayList<Blocco> blocks, Grid griglia) {

    int initialPos;  //x iniziale
    int initialY = 0;
    int grandezza = 0;  //indica quanto il blocco generato è grande

    switch(type) {
    case BlockType.Straight:

      initialPos = (int)random(w);
      blocks.add(new Blocco(BlockType.Straight, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Straight, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Straight, initialPos, initialY+2));

      grandezza = 3;

      break;
    case BlockType.L:

      initialPos = (int)random(w-1);
      blocks.add(new Blocco(BlockType.L, initialPos, initialY));
      blocks.add(new Blocco(BlockType.L, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.L, initialPos, initialY+2));
      blocks.add(new Blocco(BlockType.L, initialPos + 1, initialY+2));

      grandezza = 4;

      break;
    case BlockType.Square:

      initialPos = (int)random(w-1);
      blocks.add(new Blocco(BlockType.Square, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Square, initialPos + 1, initialY));
      blocks.add(new Blocco(BlockType.Square, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Square, initialPos + 1, initialY+1));

      grandezza = 4;

      break;
    case BlockType.Plus:

      initialPos = (int)random(w-2);
      blocks.add(new Blocco(BlockType.Plus, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Plus, initialPos + 1, initialY));
      blocks.add(new Blocco(BlockType.Plus, initialPos + 2, initialY));
      blocks.add(new Blocco(BlockType.Plus, initialPos + 1, initialY+1));

      grandezza = 4;

      break;
    case BlockType.Lightning:

      initialPos = (int)random(w-1);
      blocks.add(new Blocco(BlockType.Lightning, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Lightning, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Lightning, initialPos + 1, initialY+1));
      blocks.add(new Blocco(BlockType.Lightning, initialPos + 1, initialY+2));

      grandezza = 4;

      break;
    case BlockType.Short:

      initialPos = (int)random(w);
      blocks.add(new Blocco(BlockType.Short, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Short, initialPos, initialY+1));

      grandezza = 2;

      break;
    case BlockType.Long:

      initialPos = (int)random(w);
      blocks.add(new Blocco(BlockType.Long, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Long, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Long, initialPos, initialY+2));
      blocks.add(new Blocco(BlockType.Long, initialPos, initialY+3));

      grandezza = 4;

      break;
      
   case BlockType.NegativeLightning:
     
      initialPos = (int)random(w-1);
      blocks.add(new Blocco(BlockType.Lightning, initialPos + 1, initialY));
      blocks.add(new Blocco(BlockType.Lightning, initialPos + 1, initialY+1));
      blocks.add(new Blocco(BlockType.Lightning, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Lightning, initialPos, initialY+2));

      grandezza = 4;

      break;
   
    default:
      println("Error BlockType");
    }

    //CONTROLLO GAMEOVER
    for (int i = 1; i <= grandezza; i++) {  //controllo se gli ultimi blocchi spawnati son già occupati, in tal caso gameOver
      int riga = (int)blocks.get(blocks.size()-i).pos.y;
      int colonna = (int)blocks.get(blocks.size()-i).pos.x;
      if (griglia.grid[riga][colonna] != -1) {
        gameOver = true;
      }
    }
  }

  public void loadBlocksAnteprima(int type, ArrayList<Blocco> blocks) {  //metodo per generare l'array di blocchi in anteprima

    int initialPos = 0;  //x iniziale
    int initialY = 0;
    
    blocks.clear();  //svuota array blocchi in anteprima prima di generarne nuovi
    
    switch(type) {
    case BlockType.Straight:
      blocks.add(new Blocco(BlockType.Straight, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Straight, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Straight, initialPos, initialY+2));

      break;
    case BlockType.L:
      blocks.add(new Blocco(BlockType.L, initialPos, initialY));
      blocks.add(new Blocco(BlockType.L, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.L, initialPos, initialY+2));
      blocks.add(new Blocco(BlockType.L, initialPos + 1, initialY+2));

      break;
    case BlockType.Square:
      blocks.add(new Blocco(BlockType.Square, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Square, initialPos + 1, initialY));
      blocks.add(new Blocco(BlockType.Square, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Square, initialPos + 1, initialY+1));

      break;
    case BlockType.Plus:
      blocks.add(new Blocco(BlockType.Plus, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Plus, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Plus, initialPos, initialY+2));
      blocks.add(new Blocco(BlockType.Plus, initialPos + 1, initialY + 1));

      break;
    case BlockType.Lightning:
      blocks.add(new Blocco(BlockType.Lightning, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Lightning, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Lightning, initialPos + 1, initialY+1));
      blocks.add(new Blocco(BlockType.Lightning, initialPos + 1, initialY+2));

      break;
    case BlockType.Short:
      blocks.add(new Blocco(BlockType.Short, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Short, initialPos, initialY+1));

      break;
    case BlockType.Long:
      blocks.add(new Blocco(BlockType.Long, initialPos, initialY));
      blocks.add(new Blocco(BlockType.Long, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Long, initialPos, initialY+2));
      blocks.add(new Blocco(BlockType.Long, initialPos, initialY+3));

      break;

    case BlockType.NegativeLightning:
      
      blocks.add(new Blocco(BlockType.Lightning, initialPos + 1, initialY));
      blocks.add(new Blocco(BlockType.Lightning, initialPos + 1, initialY+1));
      blocks.add(new Blocco(BlockType.Lightning, initialPos, initialY+1));
      blocks.add(new Blocco(BlockType.Lightning, initialPos, initialY+2));

      break;
      
    default:
      println("Error BlockType");
    }
  }

  //Gestisce le rotazioni
  public void rotate(ArrayList<Blocco> blocks) {
    RotationManager rotationManager = new RotationManager(blocks.get(blocks.size() - 1).type);
    rotationManager.InvertX(blocks);
    boolean freedom = rotationManager.Flap(blocks);
    if (!freedom) 
      rotationManager.InvertY(blocks);
  }
}
class Grid {
  int [][] grid;

  //griglia di posizioni nell'array list, ogni cella della griglia conterrò l'indice del blocco che la occupa relativo all'arrayList blocks

  Grid(int h, int w) {
    grid = new int[h][w];
    for (int i=0; i<h; i++)
      for (int j=0; j<w; j++)
        grid[i][j] = -1;
  }

  public void printGrid() {
    translate(200, 0);
    stroke(100);
    for (int i=0; i<h; i++)
      line(0, i*height/h, width-200, i*height/h);
    for (int i=0; i<width-200; i++)
      line(i*(width-200)/w, 0, i*(width-200)/w, height);
  }

  public void updateGriglia(ArrayList<Blocco> blocchi) {  //riempie la griglia con le coordinate di ogni blocco
    for (int i=0; i<h; i++)  //svuoto tutta la griglia
      for (int j=0; j<w; j++)
        grid[i][j] = -1;


    //è UN FOR CATTIVO NON TOCCARLO PERCHé MORDE
    for (int i = blocchi.size()-1; i >=0; i--) {  
      if (blocchi.get(i).staScendendo && !bloccoInDiscesa) {  //segno come "non in discesa" quando la caduta deve fermarsi
        blocchi.get(i).staScendendo = false;
      }

      if (blocchi.get(i).del) {  //se è da eliminare lo elimino
        blocchi.remove(i);
      }
    }

    //riempio nuovamente la griglia
    for (int i = blocchi.size()-1; i >=0; i--)
      grid[(int)blocchi.get(i).pos.y][(int)blocchi.get(i).pos.x] = i;
  }

  public void eliminaRiga(int n, ArrayList<Blocco> blocchi) {  //elimina una singola riga e sposta tutte quelle sopra in già
    eliminaRigaSound.play();
    //sposto in giù tutte le rige superiori modificando la coordinata nella lista
    for (int i = n-1; i > 0; i--) {
      for (int j = 0; j < w; j++) {
        if (grid[i][j] != -1) {  //se non è vuoto
          blocchi.get(grid[i][j]).pos.y ++;  //aumento la y
        }
      }
    }

    //scorro tutte le colonne della riga da eliminare e segno i blocchi come da eliminare dalla lista
    for (int j = w-1; j >= 0; j--) {
      blocchi.get(grid[n][j]).del = true;
    }

    updateGriglia(blocchi);  //riempio di nuovo la griglia correttamente
  }

  public void controlloEliminazione(ArrayList<Blocco> blocchi) {  //controlla se riga va eliminata 
    //controlla ogni riga, le salva in un array, aumenta i punti ed elima riga per riga

    ArrayList<Integer> righeDaEliminare = new ArrayList<Integer>();
    boolean daEliminare = true;  //è true quando va eliminata la riga

    for (int i = 0; i < h; i++) { //scorre le righe dalla prima in alto a scendere (si elimina da quella più in alto)
      daEliminare = true;
      for (int j = 0; j < w; j++) {
        if (grid[i][j] == -1) {  //quando trovo una cella vuota passo alla prossima riga
          daEliminare = false;
        }
      }
      //se la riga è piena la metto in lista per l'eliminazione
      if (daEliminare) {
        righeDaEliminare.add(i);
        righeEliminate++;
      }
    }

    //aggiungo punti in base al numero di righe da eliminare (size della lista)
    switch(righeDaEliminare.size()) {
    case 0:  //se non ci son righe da eliminare non aggiungo punti
      break;
    case 1:
      punti += 50 * (lvl+1);
      break;
    case 2:
      punti += 150 * (lvl+1);
      break;
    case 3:
      punti += 350 * (lvl+1);
      break;
    default:  //da 4 righe in avanti
      punti += 1000 * (lvl+1);
      break;
    }
    
    //eliminazione effettiva delle righe
    if (!bloccoInDiscesa)
      for (int i = 0; i < righeDaEliminare.size(); i++) {
        eliminaRiga(righeDaEliminare.get(i), blocchi);
      }

    nextLvl += righeDaEliminare.size(); //aumento il contatore di righe eliminate
    
    if (nextLvl >= 10) { //guardo se ho eliminato almeno 10 righe in questo livello
      lvl++; //aumento di livello
      nextLvl = 0; //azzero il contatore
      aum = (int)map(lvl, 0, 30, 700, 10); //rimappo la velocità in base al livello
      aumDefault = aum; //assegno la vel default del livello a questa var
      blockOffset+=aum; //boh??
    }
  }
}
class Gui {

  ArrayList<Blocco> leftBlocks = new ArrayList<Blocco>();  //blocchi di anteprima
  
  PImage leftTab;
  PImage mainmenu;
  PImage maintitle;
  PImage gameOverImg;

  Gui() { //load della grafica
    leftTab = loadImage("leftsidetab2.png");
    mainmenu = loadImage("main_menu.png");
    gameOverImg = loadImage("game_over.png");
    maintitle = loadImage("tetrox.png");
  }

  public void mostra() {
    translate(-200, 0); //mi sposto all'origine
    
    imageMode(CENTER);
    image(maintitle, 100, 85, 180, 54); //stampo nome gioko
    imageMode(CORNER);
    
    fill(100); //faccio il pulsante pausa
    rect(20, height/2-150, 160, 55, 5);
    
    textSize(16); //stampo varie cose
    fill(255);
    text("Punti: "+punti, 100, 160);
    fill(0xffd93444);
    text("Righe eliminate: "+righeEliminate, 100, 180);
    fill(255);
    text("Livello: "+lvl, 100, 200);
    fill(0xffd93444);
    text("Tempo di gioco: "+ (timeGame - timeoffset)/1000, 100, 220); //faccio il calcolo del tempo di gioco effettivo
    
    fill(255);
    textSize(18);
    text("PREMI P PER\nPAUSA", 100, height/2-130);
    textSize(15);
    text("Premi X per \nruotare il blocco", 100, 340);
    fill(0xffd93444);
    text("Premi C\nper l'hard drop", 100, 385);
    fill(255);
    text("Premi Freccia in giù\nper velocizzare la discesa", 100, 430);
    noFill();
    
    image(leftTab, 0, 480); //stampo la sprite del muro a sx
    
    translate(80, 560); //stampo i blocchi in anteprima
    for (Blocco i : leftBlocks)
      i.show();
    translate(-80, -560);
  }

  public void stampoPausa() {
    fill(100);
    rect(20, height/2-150, 160, 55, 5); //stampo pulsante
    noFill();
    fill(255);
    textSize(18); //stampo testo per riprendere il gioco
    text("PREMI P PER\nRIPRENDERE", 100, height/2-130);
    noFill();
  }

  public void stampoGameOver() {
    imageMode(CENTER);
    image(gameOverImg, 400, 200); //stampo img gameover
    if (musicTrack == 1) music1.stop(); //fermo la traccia corretta
    else music2.stop();
    noLoop(); //stoppo il draw
    gameOverSound.play(); //riproduco la musica di gameover
  }

  public void stampoMenu() {
    if (!avviato) { //se non ho avviato con z stampo il menù principale
      timeoffset = millis() - aum; //preparo un offset per azzerare il tempo di gioco finchè non si avvia effettivamente
      image(mainmenu, 0, 0); //stampo il bg
      imageMode(CENTER);
      image(maintitle, width/2, 300); //stampo il titolo
      imageMode(CORNER);
      textSize(25);
      fill(255);
      text("PREMI Z PER INIZIARE", 300, 430); //scrivo puttanate
      text("PREMI A PER CAMBIARE LA MUSICA\nTRACCIA CARICATA: " + musicTrack, 300, 630);
    } else { //se ho avviato seleziono la traccia e la faccio partire, impostando musicLoaded a true
      if (musicTrack == 1) {
        music1.amp(0.05f);
        music1.loop();
      } else {
        music2.amp(0.1f);
        music2.loop();
      }
      musicLoaded = true;
    }
  }
}
class RotationManager {

  int type;

  public RotationManager(int t) {
    type = t;
  }

  //Ribalta i blocchi
  public boolean Flap(ArrayList<Blocco> blocks) {

    int maxX = getMax(blocks, true);
    int maxY = getMax(blocks, false);

    int minX = getMin(blocks, true);
    int minY = getMin(blocks, false);

    boolean overflow = OverflowBlocks(blocks);
    int dist = getDistance(blocks);
    boolean freedom = (minX + dist) < 10 && !overflow;

    if (freedom) { //All' inizio controlla se i blocchi non fuoriescono dai bordi
      for (Blocco block : blocks) {

        if (block.staScendendo && type == block.type) { 
          PVector pattern = new PVector((maxX - minX) - (maxX - block.pos.x), 
            (maxY - minY) - (maxY - block.pos.y));
          block.pos.x = minX + pattern.y;
          block.pos.y = minY + pattern.x;
        }
      }
    }

    return freedom;
  }

  //Inverte i blocchi da sinistra a destra o viceversa
  public void InvertX(ArrayList<Blocco> blocks) {

    float max = getMax(blocks, true);
    float min = getMin(blocks, true);

    for (Blocco block : blocks) {
      if (block.staScendendo && type == block.type) {
        block.pos.x = min + (max - block.pos.x);
      }
    }
  }

  //Inverte i blocchi dal basso all' alto o viceversa
  public void InvertY(ArrayList<Blocco> blocks) {

    float max = getMax(blocks, false);
    float min = getMin(blocks, false);

    for (Blocco block : blocks) {
      if (block.staScendendo && type == block.type) {
        block.pos.y = min + (max - block.pos.y);
      }
    }
  }

  //Ritorna la coordinata x o y maggiore
  private int getMax(ArrayList<Blocco> blocks, boolean forX) {

    int max = -1;

    for (Blocco block : blocks) {
      if (block.staScendendo) {
        if (forX) {
          if (max < block.pos.x) 
            max = (int)block.pos.x;
        } else {
          if (max < block.pos.y) 
            max = (int)block.pos.y;
        }
      }
    }

    return max;
  }

  private int getDistance(ArrayList<Blocco> blocks) {
    int min = getMin(blocks, false);
    int max = getMax(blocks, false);

    return (max - min) + 1;
  }

  //Ritorna la coordinata x o y minore
  private int getMin(ArrayList<Blocco> blocks, boolean forX) {

    int min = 20;

    for (Blocco block : blocks) {
      if (block.staScendendo) {
        if (forX) {
          if (min > block.pos.x) 
            min = (int)block.pos.x;
        } else {
          if (min > block.pos.y) 
            min = (int)block.pos.y;
        }
      }
    }

    return min;
  }

  //Controlla che i blocchi che scendono non intersechino con i blocchi fermi
  private boolean OverflowBlocks(ArrayList<Blocco> blocks) {
    boolean res = false;
    float d = 0;
    int maxX = getMax(blocks, true);
    int maxY = getMax(blocks, false);
    int dist = getDistance(blocks);

    for (Blocco block : blocks) {
      if (!block.staScendendo && (block.pos.x > maxX && block.pos.y <= maxY)) {
        d = block.pos.x - maxX;
        if (d < dist) {
          res = true;
          break;
        }
      }
    }

    return res;
  }
}
  public void settings() {  size(600, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "tetrox" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
